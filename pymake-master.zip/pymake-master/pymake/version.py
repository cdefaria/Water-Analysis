# pymake version file automatically created using...pre-commit.py
# created on...September 28, 2017 16:50:09

major = 1
minor = 1
micro = 26
commit = 211

__version__ = '{:d}.{:d}'.format(major, minor)
__build__ = '{:d}.{:d}.{:d}'.format(major, minor, micro)
__git_commit__ = '{:d}'.format(commit)
