#!/bin/sh
echo 'Running python'
python pre-commit.py

echo 'Finished pre-commit'
